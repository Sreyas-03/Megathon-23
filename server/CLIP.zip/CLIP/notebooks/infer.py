import torch
import clip
from PIL import Image
import json

import ssl

try:
    _create_unverified_https_context = ssl._create_unverified_context
except AttributeError:
    # Legacy Python that doesn't verify HTTPS certificates by default
    pass
else:
    # Handle target environment that doesn't support HTTPS verification
    ssl._create_default_https_context = _create_unverified_https_context

device = "cuda" if torch.cuda.is_available() else "cpu"
model, preprocess = clip.load("ViT-B/32", device=device)

# linkedin = None
# with open(f"linkedIn_clean.json", "r") as f:
#     linkedin = json.load(f)

# print(linkedin[0])
# image = preprocess(Image.open("../img.jpeg")).unsqueeze(0).to(device)
prompt = "As a Talent Acquisition Specialist at Genpact, I am responsible for sourcing, screening, and hiring qualified candidates for various roles across the organization. I use innovative methods and available resources to identify and attract talent, and ensure a positive candidate experience throughout the recruitment process. I also collaborate with hiring managers and other stakeholders to understand their needs and expectations, and provide them with regular feedback and updates. I have completed my MBA from IIBM Institute of Business Management, with a focus on International Business and Foreign Trade. I have a strong academic background in commerce and management, having completed my M.Com from University of Rajasthan and my PGDM in HR from Symbiosis Centre for Distance Learning. I have also obtained certifications in HR and Corporate Strategy from Forage and Rivcon Agroservices Pvt Ltd, respectively. I am passionate about learning new skills and expanding my knowledge in the fields of HR and international business."

import spacy
from spacy.lang.en.stop_words import STOP_WORDS
from string import punctuation
from heapq import nlargest

def summarize(text, per):
    nlp = spacy.load('en_core_web_sm')
    doc= nlp(text)
    tokens=[token.text for token in doc]
    word_frequencies={}
    for word in doc:
        if word.text.lower() not in list(STOP_WORDS):
            if word.text.lower() not in punctuation:
                if word.text not in word_frequencies.keys():
                    word_frequencies[word.text] = 1
                else:
                    word_frequencies[word.text] += 1
    max_frequency=max(word_frequencies.values())
    for word in word_frequencies.keys():
        word_frequencies[word]=word_frequencies[word]/max_frequency
    sentence_tokens= [sent for sent in doc.sents]
    sentence_scores = {}
    for sent in sentence_tokens:
        for word in sent:
            if word.text.lower() in word_frequencies.keys():
                if sent not in sentence_scores.keys():                            
                    sentence_scores[sent]=word_frequencies[word.text.lower()]
                else:
                    sentence_scores[sent]+=word_frequencies[word.text.lower()]
    select_length=int(len(sentence_tokens)*per)
    summary=nlargest(select_length, sentence_scores,key=sentence_scores.get)
    final_summary=[word.text for word in summary]
    summary=''.join(final_summary)
    return summary

summarize(prompt, 0.05)


# prompt = "As a Talent Acquisition Specialist at Genpact, I am responsible for sourcing, screening, and hiring qualified candidates for various roles across the organization. I use innovative methods and available resources to identify and attract talent, and ensure a positive candidate experience throughout the recruitment process."
# # prompt = "I hire people"

# text = clip.tokenize([prompt]).to(device)

# # prompts = ["I hire people", "I am a hiring manager", "I am a dancer", "I am a software engineer", " ", "I am a singer", "I used to hire people", "I am a wrestler", "I am a software engineer", "Software engineer", "I hire people. I am not a software engineer.", "I am a software engineer. I don't hire people.", "I hire people."]
# prompts = ["software engineer not hire and not sales person", "sales person not software engineer", "researcher", "manager", "hire"]
# prompt_tokens = [clip.tokenize([prompt]).to(device) for prompt in prompts]

# with torch.no_grad():
#     image_features = [model.encode_text(prompt_token) for prompt_token in prompt_tokens]
#     image_features = torch.stack(image_features, dim=0)
#     text_features = model.encode_text(text)
#     image_features /= image_features.norm(dim=-1, keepdim=True)
#     text_features /= text_features.norm(dim=-1, keepdim=True)
#     dist_mat = image_features @ text_features.T

#     for prompt, dist in zip(prompts, dist_mat):
#         print(f"{prompt}: {dist[0].item()}")
#     # print(f"Cosine Distance : {image_features @ text_features.T}")
#     # logits_per_image, logits_per_text = model(image, text)
#     # probs = logits_per_image.softmax(dim=-1).cpu().numpy()

# # print("Label probs:", probs)  # prints: [[0.9927937  0.00421068 0.00299572]]